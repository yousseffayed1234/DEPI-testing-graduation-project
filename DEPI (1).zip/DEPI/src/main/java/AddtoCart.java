import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import java.util.concurrent.TimeUnit;

import java.util.concurrent.TimeUnit;

public class AddtoCart {
    public static void main(String[] args) {
        System.setProperty("webdriver.chrome.driver","C:\\Users\\HP\\IdeaProjects\\DEPI\\Drivers\\chromedriver.exe");
        WebDriver driver= new ChromeDriver();
        driver.get("https://magento.softwaretestingboard.com/what-is-new.html");
        driver.manage().window().maximize();

        WebElement searchBar = driver.findElement(By.xpath("//input[@id='search']"));
        searchBar.sendKeys("Jacket");


        WebElement ButtonSearch = driver.findElement(By.xpath("//button[@title='Search']"));
        ButtonSearch.click();

        //Scrolling down slowly
        JavascriptExecutor js = (JavascriptExecutor) driver;
        for (int i = 0; i < 1000; i += 50) {
            js.executeScript("window.scrollBy(0, 50);");
            try {
                Thread.sleep(100); // Pause for 100 milliseconds
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        driver.get("https://magento.softwaretestingboard.com/lando-gym-jacket.html");

        WebElement targetElement = driver.findElement(By.xpath("//span[@id='option-label-size-143']"));
        // Get the target element's position
        int targetPosition = targetElement.getLocation().getY();
        // Scroll to the target position
        JavascriptExecutor jss = (JavascriptExecutor) driver;
        jss.executeScript("window.scrollTo(0, " + targetPosition + ");");


        WebElement SelectSize= driver.findElement(By.xpath("//div[@id='option-label-size-143-item-167']"));
        SelectSize.click();


        WebElement targettElement = driver.findElement(By.xpath("//span[@id='option-label-color-93']"));
        // Get the target element's position
        int targettPosition = targettElement.getLocation().getY();
        // Scroll to the target position
        JavascriptExecutor j = (JavascriptExecutor) driver;
        j.executeScript("window.scrollTo(0, " + targettPosition + ");");


        WebElement SelectColor = driver.findElement(By.xpath("//div[@id='option-label-color-93-item-52']"));
        SelectColor.click();

        WebElement AddtoCart = driver.findElement(By.xpath("//span[normalize-space()='Add to Cart']"));
        AddtoCart.click();

        driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);


        WebElement Element = driver.findElement(By.xpath("//a[@class='action showcart']"));
        // Get the target element's position
        int Position = Element.getLocation().getY();
        // Scroll to the target position
        JavascriptExecutor JS = (JavascriptExecutor) driver;
        JS.executeScript("window.scrollTo(0, " + Position + ");");

















    }
}
